const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');


function setupCanvas() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const backgroundImage = new Image();
    backgroundImage.src = 'images/background.png';
    backgroundImage.onload = () => {
        ctx.drawImage(backgroundImage, 0, 0, canvas.width, canvas.height);
        drawButtons();  // Ensure buttons are drawn
    };
}

document.addEventListener('DOMContentLoaded', function() {
    setupCanvas();
});


function drawButtons() {
    // Hit Button
    ctx.fillStyle = '#4CAF50'; 
    ctx.fillRect(50, canvas.height - 100, 100, 50); 
    ctx.fillStyle = 'white'; 
    ctx.font = '20px Arial';
    ctx.fillText('Hit', 75, canvas.height - 65);

    // Stand Button
    ctx.fillStyle = '#f44336'; 
    ctx.fillRect(200, canvas.height - 100, 100, 50); 
    ctx.fillStyle = 'white'; 
    ctx.fillText('Stand', 215, canvas.height - 65);

    // Deal Button
    ctx.fillStyle = '#008CBA'; 
    ctx.fillRect(350, canvas.height - 100, 100, 50); 
    ctx.fillStyle = 'white'; 
    ctx.fillText('Deal', 375, canvas.height - 65);

    ctx.fillStyle = '#DDA0DD'; 
    ctx.fillRect(500, canvas.height - 100, 100, 50); 
    ctx.fillStyle = 'white'; 
    ctx.fillText('Double', 525, canvas.height - 75);
    ctx.fillText('Down', 520, canvas.height - 55);

}
//Event Listner function for checking if buttons are clicked
canvas.addEventListener('click', function(event) {
    const rect = canvas.getBoundingClientRect(); 
    const x = event.clientX - rect.left; 
    const y = event.clientY - rect.top; 

    if (x >= 50 && x <= 150 && y >= canvas.height - 100 && y <= canvas.height - 50) {
        if (gameStarted) {
            playerHand.push(dealCard());
            checkPlayerHand();
            renderHands();
        }
    }

    // Stand Button
    if (x >= 200 && x <= 300 && y >= canvas.height - 100 && y <= canvas.height - 50) {
        if (gameStarted) {
            dealerDecision();
        }
    }

    // Deal Button
    if (x >= 350 && x <= 450 && y >= canvas.height - 100 && y <= canvas.height - 50) {
        shuffleDeck(deck);
        startGame();
    }

    //Split function 
    if (x >= 500 && x <= 600 && y >= canvas.height - 100 && y <= canvas.height - 50) {
        if (gameStarted && canSplit(playerHand)) {
            splitHand();
        }
    }

    //Check if the double down buton is clicked
    if (x >= 500 && x <= 600 && y >= canvas.height - 100 && y <= canvas.height - 50) {
        if (gameStarted && playerHand.length === 2) { // Can only double down with exactly 2 cards
            doubleDown();
        }
    }
});

const deck = [
    //Clubs
    { card: '2C', img: 'images/cardClubs2.png' },
    { card: '3C', img: 'images/cardClubs3.png' },
    { card: '4C', img: 'images/cardClubs4.png' },
    { card: '5C', img: 'images/cardClubs5.png' },
    { card: '6C', img: 'images/cardClubs6.png' },
    { card: '7C', img: 'images/cardClubs7.png' },
    { card: '8C', img: 'images/cardClubs8.png' },
    { card: '9C', img: 'images/cardClubs9.png' },
    { card: '10C', img: 'images/cardClubs10.png' },
    { card: 'JC', img: 'images/cardClubsJ.png' },
    { card: 'QC', img: 'images/cardClubsQ.png' },
    { card: 'KC', img: 'images/cardClubsK.png' },
    { card: 'AC', img: 'images/cardClubsA.png' },
    //Diamonds
    { card: '2D', img: 'images/cardDiamonds2.png' },
    { card: '3D', img: 'images/cardDiamonds3.png' },
    { card: '4D', img: 'images/cardDiamonds4.png' },
    { card: '5D', img: 'images/cardDiamonds5.png' },
    { card: '6D', img: 'images/cardDiamonds6.png' },
    { card: '7D', img: 'images/cardDiamonds7.png' },
    { card: '8D', img: 'images/cardDiamonds8.png' },
    { card: '9D', img: 'images/cardDiamonds9.png' },
    { card: '10D', img: 'images/cardDiamonds10.png' },
    { card: 'JD', img: 'images/cardDiamondsJ.png' },
    { card: 'QD', img: 'images/cardDiamondsQ.png' },
    { card: 'KD', img: 'images/cardDiamondsK.png' },
    { card: 'AD', img: 'images/cardDiamondsA.png' },
    // Hearts
    { card: '2H', img: 'images/cardHearts2.png' },
    { card: '3H', img: 'images/cardHearts3.png' },
    { card: '4H', img: 'images/cardHearts4.png' },
    { card: '5H', img: 'images/cardHearts5.png' },
    { card: '6H', img: 'images/cardHearts6.png' },
    { card: '7H', img: 'images/cardHearts7.png' },
    { card: '8H', img: 'images/cardHearts8.png' },
    { card: '9H', img: 'images/cardHearts9.png' },
    { card: '10H', img: 'images/cardHearts10.png' },
    { card: 'JH', img: 'images/cardHeartsJ.png' },
    { card: 'QH', img: 'images/cardHeartsQ.png' },
    { card: 'KH', img: 'images/cardHeartsK.png' },
    { card: 'AH', img: 'images/cardHeartsA.png' },
    // Spades
    { card: '2S', img: 'images/cardSpades2.png' },
    { card: '3S', img: 'images/cardSpades3.png' },
    { card: '4S', img: 'images/cardSpades4.png' },
    { card: '5S', img: 'images/cardSpades5.png' },
    { card: '6S', img: 'images/cardSpades6.png' },
    { card: '7S', img: 'images/cardSpades7.png' },
    { card: '8S', img: 'images/cardSpades8.png' },
    { card: '9S', img: 'images/cardSpades9.png' },
    { card: '10S', img: 'images/cardSpades10.png' },
    { card: 'JS', img: 'images/cardSpadesJ.png' },
    { card: 'QS', img: 'images/cardSpadesQ.png' },
    { card: 'KS', img: 'images/cardSpadesK.png' },
    { card: 'AS', img: 'images/cardSpadesA.png' }
];

let playerHand = [];
let dealerHand = [];
let gameStarted = false;

// Function to shuffle the deck
function shuffleDeck(deck) {
    for (let i = deck.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [deck[i], deck[j]] = [deck[j], deck[i]];
    }
}

// Function to deal a card
function dealCard() {
    return deck.pop();
}

// Function to start the game
function startGame() {
    playerHand = [dealCard(), dealCard()];
    dealerHand = [dealCard(), dealCard()];
    gameStarted = true;
    renderHands();
}


function renderHands(showAllDealerCards = false) {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const backgroundImage = new Image();
    backgroundImage.src = 'images/background.png';
    backgroundImage.onload = () => {
        ctx.drawImage(backgroundImage, 0, 0, canvas.width, canvas.height);
        drawHand(playerHand, (canvas.width - playerHand.length * 70) / 2, canvas.height - 250, true); 
        drawHand(dealerHand, (canvas.width - dealerHand.length * 70) / 2, 150, showAllDealerCards); 
        drawButtons()
    };
}

function drawHand(hand, startX, y, faceUp, offset = 30){
    hand.forEach((card, index) => {
        drawCard(card, startX + index * offset, y, faceUp || index === 0);
    })
}

// Function to draw a card
function drawCard(card, x, y, faceUp = true) {
    const cardImage = new Image();
    if (faceUp) {
        cardImage.src = card.img;  
    } else {
        cardImage.src = 'images/card-back.png';  
    }
    cardImage.onload = () => {
        ctx.drawImage(cardImage, x, y, 50, 70);  
    };
}




shuffleDeck(deck);



// hit - deals player new card & checks sum of cards
document.getElementById('hit-btn').addEventListener('click', function () {
    if (gameStarted) {
        playerHand.push(dealCard());
        checkPlayerHand();
        renderHands(false);
    }
});

// stand - player is done with their turn, goes to dealer's turn
document.getElementById('stand-btn').addEventListener('click', function () {
    // to be implemented
    if(gameStarted){
        dealerDecision();
    }
    console.log("Clicked hit button");
});

function canSplit(hand) {
    if (hand.length === 2 && hand[0].card.slice(0, -1) === hand[1].card.slice(0, -1)) {
        return true;  // Both cards have the same rank
    }
    return false;
}

let splitHands = [];

function splitHand() {
    if (!canSplit(playerHand)) {
        alert("Cannot split this hand.");
        return; 
    }

    // Create two separate hands from the original hand
    splitHands = [
        [playerHand[0], dealCard()],  // Hand 1
        [playerHand[1], dealCard()]   // Hand 2
    ];
    gameStarted = true; // Ensure the game is marked as started
    renderHands(); // Redraw the canvas with split hands
}

function doubleDown() {
    playerHand.push(dealCard());
    gameStarted = false;
    renderHands(true);
    dealerDecision();
}



function dealerDecision() {
    let dealerScore = calculateHandValue(dealerHand);
    while (dealerScore < 17 || (dealerScore === 17 && dealerHand.includes('A'))) {
        dealerHand.push(dealCard());
        dealerScore = calculateHandValue(dealerHand);
    }
    renderHands(true);
    checkGameOutcome();
}

function calculateHandValue(hand) {
    let sum = 0;
    let aces = 0;
    hand.forEach(card => {
        const value = card.card.slice(0, -1); 
        if (value === 'A') {
            aces += 1;
            sum += 11; 
        } else if (['J', 'Q', 'K', '10'].includes(value)) {
            sum += 10;
        } else {
            sum += parseInt(value); 
        }
    });
    // Adjust for aces if the sum is over 21
    while (sum > 21 && aces > 0) {
        sum -= 10;
        aces -= 1;
    }
    return sum;
}


function checkGameOutcome() {
    const playerScore = calculateHandValue(playerHand);
    const dealerScore = calculateHandValue(dealerHand);
    let message;
    if (playerScore > 21) {
        message = "You bust! Dealer wins.";
    } else if (dealerScore > 21) {
        message = "Dealer busts! You win.";
    } else if (playerScore > dealerScore) {
        message = "You win!";
    } else if (playerScore < dealerScore) {
        message = "Dealer wins.";
    } else {
        message = "It's a tie!";
    }
    alert(message);
    gameStarted = false; // Prevent further actions
}
// deal - resets the game
document.getElementById('deal-btn').addEventListener('click', function () {
    //shuffleDeck(deck);
    startGame();
});


function checkPlayerHand() {
    let sum = 0;
    let aces = 0;
    playerHand.forEach(card => {
        const value = card.card.slice(0, -1); // Extract the value part, slicing off the suit
        if (value === 'A') {
            aces += 1;
            sum += 11; // Initially count aces as 11
        } else if (['J', 'Q', 'K', '10'].includes(value)) {
            sum += 10;
        } else {
            sum += parseInt(value); // Directly parse the numeric value
        }
    });
    // Adjust for aces if the sum is over 21
    while (sum > 21 && aces > 0) {
        sum -= 10;
        aces -= 1;
    }
    if (sum > 21) {
        alert("Bust! You lose.");
        gameStarted = false;  //Prevents any other actions
    }
}

